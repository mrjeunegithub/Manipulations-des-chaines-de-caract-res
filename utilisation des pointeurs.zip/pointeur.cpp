#include <iostream>

#include "pointeur.h"

int pointeur::longueur(const char *chaine) {
    int longueur = 0;

    while (*chaine != '\0')  {
        longueur++ ;
        chaine++ ;
    }
    return longueur;
}

void pointeur::copie(char* dest, const char * source) {

    while ((*dest++ = *source++) != '\0') ;
}

void pointeur::concatene(char* dest, const char* source){

    while (*dest != '\0') {
        dest++;             //On avance d'abord le pointeur dest jusqu'a la fin
    }
    while ((*dest++ = *source++) != '\0');// ON ajoute ensuite source a dest

}

int pointeur::compare(const char* chaine1, const char* chaine2) {
    while (*chaine1 != '\0' && *chaine2 != '\0') {

        if (*chaine1 != *chaine2) {
            return *chaine1 - *chaine2;
        }
        chaine1++;chaine2++;
        
    }
    // Si une chaîne s'est terminée avant l'autre
    return *chaine1 - *chaine2;
}


