#ifndef POINTEUR_H
#define POINTEUR_H

class pointeur{
public:

    int longueur(const char *chaine );
    void copie(char *dest, const char *source);
    void concatene(char *dest, const char * source);
    int compare(const char*chaine1, const char * chaine2);
};


#endif 
