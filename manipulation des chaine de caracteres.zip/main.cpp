#include <iostream>

#include "pointeur.h"


int main(int argc, char **argv) {
    //Utilisation de la fonction de determination de la longueur d'une chaine de caractere
    pointeur pointeur;

    const char *chaine1 = "bonjour";
    const char *chaine2 = "moyen jour";
    const char *chaine3 = "mauvais jour";

    std::cout << "la longueur de <bonjour> est  :"<< pointeur.longueur(chaine1)<< std::endl;
    std::cout << "la longueur de <moyen jour> est  :"<< pointeur.longueur(chaine2) <<std::endl ;
    std::cout << "la longueur de <mauvais jour> est  :"<< pointeur.longueur(chaine3) << std::endl;


    //Utilisation de la fonction de copie
    const char *original = "bonsoir";
    char copieur[100];

    pointeur.copie(copieur, original);
    std::cout << copieur<< std::endl;


    //Utilisation de la fonction de concatenation
    char concat[110] = "demain sera un ";
    pointeur.concatene(concat, chaine1 );
    std::cout << concat<< std::endl;


    //Utilisation de la comparaison

    std::cout<< "Difference entre " <<chaine1<<"et " << original<< " : "<<pointeur.compare(chaine1, original)<<std::endl;
    std::cout<< "Difference entre " <<chaine2<<"et " << chaine3<< " : "<<pointeur.compare(chaine2, chaine3)<<std::endl;
    std::cout<< "Difference entre " <<chaine1<<"et " << chaine3<< " : "<<pointeur.compare(chaine1, chaine3)<<std::endl;


    return 0;
}